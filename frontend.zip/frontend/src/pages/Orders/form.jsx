import React, {useState, useEffect} from 'react';
import DashboardHeader from '../../components/DashboardHeader';

import all_orders from '../../constants/orders';
import {calculateRange, sliceData} from '../../utils/table-pagination';

import '../styles.css';
import DoneIcon from '../../assets/icons/done.svg';
import CancelIcon from '../../assets/icons/cancel.svg';
import RefundedIcon from '../../assets/icons/refunded.svg';
import UserService from '../../services/user.services';

function CompanyForm () {
    const [search, setSearch] = useState('');
    const [orders, setOrders] = useState(all_orders);
    const [page, setPage] = useState(1);
    const [name, setName] = useState("");
    const [pagination, setPagination] = useState([]);

    useEffect(() => {
        setPagination(calculateRange(all_orders, 5));
        setOrders(sliceData(all_orders, page, 5));

    }, []);

    // Search
    const __handleSearch = (event) => {
        setSearch(event.target.value);
        if (event.target.value !== '') {
            let search_results = orders.filter((item) =>
                item.first_name.toLowerCase().includes(search.toLowerCase()) ||
                item.last_name.toLowerCase().includes(search.toLowerCase()) ||
                item.product.toLowerCase().includes(search.toLowerCase())
            );
            setOrders(search_results);
        }
        else {
            __handleChangePage(1);
        }
    };

    const onChangeName = (e) => {
        const name = e.target.value;
        setName(name);
      };

    // Change Page 
    const __handleChangePage = (new_page) => {
        setPage(new_page);
        setOrders(sliceData(all_orders, new_page, 5));
    }

    const handleCompany = (e) => {
        e.preventDefault();
        UserService.addCompanies(name).then(
            () => {
              window.location.reload(true);
              console.log("Sucess");
            },
            (error) => {
              const resMessage =
                (error.response &&
                  error.response.data &&
                  error.response.data.message) ||
                error.message ||
                error.toString();
            }
          );
      };

    return(
        <div className='dashboard-content'>
          <form onSubmit={handleCompany}>
          <label> Company name</label>
          <input 
            className='form-control' 
            type='text' 
            placeholder='Company Name'
            value={name}
            onChange={onChangeName}/>
          <input className='btn btn-primary' type='submit' value='Submit' />
          <div className='error'></div>
        </form>
        </div>
    )
}

export default CompanyForm;