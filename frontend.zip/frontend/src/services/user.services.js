import axios from "axios";
const API_URL = "http://192.168.43.104/api/";

const headers = {
  "Content-Type": "text/json"
};

const getCompanies = () => {
  return axios.get(API_URL + "companies");
};

const addCompanies = (name) =>{
  return axios
  .post(API_URL + "register", {
    name,
  },
  {
    headers: headers
    })
  .then((response) => {
    //console.log(response.data)
    return response;
  });
 }





const UserService = {
  getCompanies,
  addCompanies
};

export default UserService;
