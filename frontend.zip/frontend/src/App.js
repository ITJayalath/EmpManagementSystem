import React from 'react';
import { BrowserRouter as Router, Routes, Route  } from 'react-router-dom';

import SideBar from './components/Sidebar';
import sidebar_menu from './constants/sidebar-menu';

import './App.css';
import Orders from './pages/Orders';
import Employee from './pages/Employee';
import EmployeeForm from './pages/Employee/form';
import CompanyForm from './pages/Orders/form'

function App () {
  return(
    <Router>
      <div className='dashboard-container'>
        <SideBar menu={sidebar_menu} />
          
          <div className='dashboard-body'>
              <Routes>
                  <Route path="*" element={<div></div>} />
                  <Route exact path="/" element={<div></div>} />
                  <Route exact path="/company" element={< Orders/>} />
                  <Route exact path="/employee" element={<Employee/>} />
                  <Route exact path="/employeeform" element={<EmployeeForm/>} />
                  <Route exact path="/companyform" element={<CompanyForm/>} />
                  <Route exact path="/profile" element={<div></div>} />
              </Routes>
          </div>
      </div>
    </Router>
  )
}

export default App;