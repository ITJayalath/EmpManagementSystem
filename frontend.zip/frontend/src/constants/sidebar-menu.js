import DashboardIcon from '../assets/icons/dashboard.svg';
import CompanyIcon from '../assets/icons/company.png';
import EmployeeIcon from '../assets/icons/employees.png';
import LeaveIcon from '../assets/icons/Leave.png';

const sidebar_menu = [
    {
        id: 1,
        icon: DashboardIcon,
        path: '/',
        title: 'Dashboard',
    },
    {
        id: 2,
        icon: CompanyIcon,
        path: '/company',
        title: 'Company',
    },
    {
        id: 3,
        icon: EmployeeIcon,
        path: '/employee',
        title: 'Employees',
    },
    {
        id: 4,
        icon: LeaveIcon,
        path: '/leaves',
        title: 'Leaves',
    }
]

export default sidebar_menu;